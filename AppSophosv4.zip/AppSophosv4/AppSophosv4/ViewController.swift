//
//  ViewController.swift
//  AppSophosv4
//
//  Created by Vane on 10/01/22.
//

import UIKit
import Alamofire
import MapKit


class ViewController: UIViewController {
    
    
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
   
    
    
    @IBAction func loginBtn() {
        
        let urlString = "https://6w33tkx4f9.execute-api.us-east-1.amazonaws.com/RS_Usuarios"
        guard let emailDato = emailTextField.text, let passwordDato = passwordTextField.text else {
            return
        }
        
        let parametros = ["idUsuario": emailDato, "clave": passwordDato]
        AF.request (urlString, method: .get, parameters: parametros).responseJSON { response in
            print(response)
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
    }
    
    private func setupIU(){
        loginBtn.cornerRadius = 25
    }
}








